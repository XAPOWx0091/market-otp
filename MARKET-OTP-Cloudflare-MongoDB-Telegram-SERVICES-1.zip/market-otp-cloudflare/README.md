# MARKET-OTP — Cloudflare + MongoDB starter

Starter awal MARKET-OTP menggunakan Cloudflare Workers + Static Assets + Durable Objects + MongoDB Atlas.

## Isi yang sudah ada
- Halaman login dan daftar Member.
- Akun Owner dibuat dari Cloudflare secrets saat login pertama.
- Password di-hash dengan PBKDF2-SHA256.
- Session cookie HttpOnly, SameSite=Lax, dan Secure saat HTTPS.
- Dashboard Member dan Owner.
- Owner dapat melihat jumlah akun dan daftar pengguna.
- Form pengaturan Base URL SwiftOTP dan API Key. API Key disimpan terenkripsi AES-GCM di MongoDB.
- Pengaturan notifikasi Telegram: Bot Token terenkripsi, Channel Chat ID, alamat website, sakelar aktif/nonaktif, dan tombol tes notifikasi.
- Helper backend `sendTelegramNotification(env, event)` menyediakan format notifikasi deposit berhasil dan order selesai, masing-masing dengan tombol inline menuju halaman detail (jika `detailPath` diberikan) atau halaman utama website. Notifikasi tidak meneruskan kode OTP, password, atau data autentikasi.
- Endpoint health check database.

**Belum termasuk:** alur transaksi deposit/pembayaran dan order live. Variabel contoh Austin hanya placeholder; gateway belum dihubungkan dan tidak memproses pembayaran. Karena alur transaksi belum dibuat, notifikasi otomatis untuk deposit/order belum terpicu; helper dan tombol tes Telegram sudah disiapkan untuk dipanggil oleh backend setelah event transaksi diverifikasi. Pengaturan API provider saat ini hanya menyimpan konfigurasi; tidak mengeksekusi transaksi. Gunakan hanya untuk sandbox/pengujian aplikasi milik sendiri.

## Persiapan
1. Install Node.js LTS di komputer.
2. Buat akun Cloudflare dan login lewat terminal:
   ```bash
   npx wrangler login
   ```
3. Buat database MongoDB Atlas jika belum ada. Di Atlas, tambahkan akses jaringan yang diperlukan dan buat database user khusus aplikasi. Jangan gunakan password akun utama Atlas.
4. Dari folder project:
   ```bash
   npm install
   ```
5. Tambahkan secrets (terminal akan meminta nilainya; jangan tempel secret ke chat):
   ```bash
   npx wrangler secret put MONGODB_URI
   npx wrangler secret put OWNER_USERNAME
   npx wrangler secret put OWNER_PASSWORD
   npx wrangler secret put APP_ENCRYPTION_KEY
   ```
   Gunakan password Owner yang unik dan kuat. `APP_ENCRYPTION_KEY` harus berupa nilai acak panjang dan jangan diganti setelah API Key terenkripsi tersimpan, kecuali melakukan migrasi ulang.
6. Pastikan MongoDB Atlas mengizinkan koneksi dari Cloudflare Workers. Untuk percobaan awal, cek pengaturan Network Access Atlas. Hindari membuka akses database ke publik tanpa pembatasan dan evaluasi keamanan.
7. Jalankan lokal:
   ```bash
   npm run dev
   ```
8. Deploy:
   ```bash
   npm run deploy
   ```
9. Buka URL `workers.dev` yang ditampilkan Wrangler. Login Owner memakai `OWNER_USERNAME` dan `OWNER_PASSWORD` yang disetel sebagai secrets.

## Pengaturan Telegram
1. Buat bot melalui BotFather dan jadikan bot admin di channel yang akan menerima notifikasi.
2. Ambil Channel Chat ID.
3. Login sebagai Owner, buka bagian Notifikasi Telegram, isi Bot Token, Chat ID, dan alamat website HTTPS.
4. Aktifkan notifikasi, simpan, lalu tekan Tes Notifikasi.
5. Pesan tes memiliki tombol Buka Website MARKET-OTP. Untuk event transaksi, backend perlu memanggil `sendTelegramNotification(env, { kind, reference, status, amount, detailPath })` setelah status dikonfirmasi server. `detailPath` opsional, misalnya `/history/ORDER-ID`; bila tidak ada, tombol menuju homepage.

Jenis `kind` yang didukung: `DEPOSIT_PAID`, `ORDER_COMPLETED`, `ORDER_CANCELLED`, `DEPOSIT_EXPIRED`, atau `TEST`.

## Cek koneksi database
Buka `/api/health`. Jika sukses, hasilnya `{"ok":true,"app":"MARKET-OTP","database":"connected"}`.

## Catatan penting
- Jangan pernah menaruh MongoDB URI, API Key, atau password Owner di file frontend, GitHub publik, atau chat.
- Akun yang dibuat lewat halaman Daftar selalu ber-role `member`.
- Role Owner tidak dapat dipilih dari halaman registrasi.
- Starter ini belum diaudit keamanan dan belum siap menerima uang atau dipakai sebagai layanan produksi.
- Sebelum produksi, tambahkan rate limiting, verifikasi email bila diperlukan, CSRF protection sesuai rancangan cookie, kebijakan privasi, audit keamanan, backup database, serta pengujian menyeluruh.

## Variabel Austin
`.dev.vars.example` kini menyediakan placeholder `AUSTIN_BASE_URL`, `AUSTIN_API_KEY`. Isi hanya dengan kredensial resmi di file `.dev.vars` lokal atau Cloudflare secrets setelah dokumentasi dan webhook gateway diverifikasi. Jangan commit kredensial asli.


## Provider service modules
- `src/services/swiftotp-service.js`: SwiftOTP service client with the previously supplied OTP route paths. Confirm the API-key authentication header from official docs before live use.
- `src/services/austin-pay.js`: AustinPay client scaffold. Exact endpoint paths, request payloads, and authentication header must be filled from official AustinPay cc.cd documentation; they are deliberately not guessed.
- These modules are service files; they still need to be wired into authenticated backend routes in `src/index.js` before website transactions can use them.
