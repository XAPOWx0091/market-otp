
const $ = id => document.getElementById(id);

let mode = "login";
let me = null;

function message(id, text, success = false) {
  const el = $(id);
  if (!el) return;
  el.textContent = text || "";
  el.style.color = success ? "#16804a" : "#d04444";
}

async function api(path, options = {}) {
  const response = await fetch(path, {
    ...options,
    credentials: "same-origin",
    headers: {
      ...(options.body ? { "content-type": "application/json" } : {}),
      ...(options.headers || {})
    }
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(data.error || "Permintaan gagal.");
  }

  return data;
}

function setMode(next) {
  mode = next;

  $("loginTab").classList.toggle("active", mode === "login");
  $("registerTab").classList.toggle("active", mode === "register");

  $("submitBtn").textContent =
    mode === "login" ? "MASUK" : "BUAT AKUN";

  $("password").autocomplete =
    mode === "login" ? "current-password" : "new-password";

  message("authMsg", "");
}

function showDashboard(user) {
  me = user;

  $("auth").classList.add("hidden");
  $("dashboard").classList.remove("hidden");

  $("welcome").textContent = "Masuk sebagai " + user.username;
  $("memberName").textContent = user.username;
  $("rolePill").textContent = user.role.toUpperCase();

  $("memberView").classList.toggle("hidden", user.role === "owner");
  $("ownerView").classList.toggle("hidden", user.role !== "owner");

  if ($("balance")) {
    $("balance").textContent = new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      maximumFractionDigits: 0
    }).format(user.balance || 0);
  }

  if (user.role === "owner") {
    loadOwner();
    loadUsers().catch(() => {});
  }
}

async function loadMe() {
  const data = await api("/api/me");

  if (!data.user) return false;

  showDashboard(data.user);
  return true;
}

// LOGIN / REGISTER
$("loginTab").addEventListener("click", () => setMode("login"));
$("registerTab").addEventListener("click", () => setMode("register"));

$("authForm").addEventListener("submit", async event => {
  event.preventDefault();

  const button = $("submitBtn");
  button.disabled = true;
  message("authMsg", "Memproses...", true);

  try {
    const endpoint = mode === "login"
      ? "/api/login"
      : "/api/register";

    const data = await api(endpoint, {
      method: "POST",
      body: JSON.stringify({
        username: $("username").value.trim(),
        password: $("password").value
      })
    });

    if (mode === "register") {
      setMode("login");
      message("authMsg", data.message || "Pendaftaran berhasil. Silakan masuk.", true);
      return;
    }

    if (data.user) {
      showDashboard(data.user);
    } else {
      await loadMe();
    }

  } catch (error) {
    message("authMsg", error.message);
  } finally {
    button.disabled = false;
  }
});

// LOGOUT
$("logoutBtn").addEventListener("click", async () => {
  try {
    await api("/api/logout", { method: "POST" });
  } catch (error) {
    message("authMsg", error.message);
  }

  location.reload();
});

// OWNER
async function loadOwner() {
  try {
    const data = await api("/api/admin/overview");

    $("userCount").textContent =
      data.users ?? data.stats?.totalUsers ?? "—";

    $("ownerCount").textContent =
      data.owners ?? "—";

  } catch (error) {
    $("userCount").textContent = "—";
    $("ownerCount").textContent = "—";
    console.error("Owner overview:", error);
  }

  try {
    const settings = await api("/api/admin/provider-settings");

    $("baseUrl").value =
      settings.baseUrl || "https://swiftotp.my.id/api";

    $("providerStatus").textContent =
      settings.configured
        ? "API Key tersimpan secara terenkripsi."
        : "API Key belum dikonfigurasi.";

  } catch (error) {
    $("providerStatus").textContent = error.message;
  }

  try {
    const telegram = await api("/api/admin/telegram-settings");

    $("chatId").value = telegram.chatId || "";
    $("websiteUrl").value = telegram.websiteUrl || "";
    $("telegramEnabled").checked = !!telegram.enabled;

    $("telegramStatus").textContent =
      telegram.configured
        ? "Bot Telegram sudah dikonfigurasi."
        : "Bot Telegram belum dikonfigurasi.";

  } catch (error) {
    $("telegramStatus").textContent = error.message;
  }
}

// SAVE PROVIDER
$("providerForm").addEventListener("submit", async event => {
  event.preventDefault();

  try {
    const payload = {
      baseUrl: $("baseUrl").value.trim()
    };

    if ($("apiKey").value) {
      payload.apiKey = $("apiKey").value;
    }

    const data = await api("/api/admin/provider-settings", {
      method: "POST",
      body: JSON.stringify(payload)
    });

    $("apiKey").value = "";
    message("providerMsg", data.message || "Pengaturan disimpan.", true);

    await loadOwner();

  } catch (error) {
    message("providerMsg", error.message);
  }
});

// SAVE TELEGRAM
$("telegramForm").addEventListener("submit", async event => {
  event.preventDefault();

  try {
    const payload = {
      chatId: $("chatId").value.trim(),
      websiteUrl: $("websiteUrl").value.trim(),
      enabled: $("telegramEnabled").checked
    };

    if ($("botToken").value) {
      payload.botToken = $("botToken").value;
    }

    const data = await api("/api/admin/telegram-settings", {
      method: "POST",
      body: JSON.stringify(payload)
    });

    $("botToken").value = "";
    message("telegramMsg", data.message || "Telegram disimpan.", true);

    await loadOwner();

  } catch (error) {
    message("telegramMsg", error.message);
  }
});

// TEST TELEGRAM
$("testTelegram").addEventListener("click", async () => {
  try {
    const data = await api("/api/admin/telegram-test", {
      method: "POST",
      body: JSON.stringify({})
    });

    message("telegramMsg", data.message || "Tes berhasil.", true);

  } catch (error) {
    message("telegramMsg", error.message);
  }
});

// USERS
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[char]);
}

async function loadUsers() {
  const data = await api("/api/admin/users");

  $("usersList").innerHTML = data.users?.length
    ? data.users.map(user => `
      <div class="row" style="padding:10px 0;border-bottom:1px solid #edf1f6">
        <span>
          <b>${escapeHtml(user.username)}</b><br>
          <small>${escapeHtml(user.role)} · ${escapeHtml(user.status || "active")}</small>
        </span>
        <small>${user.createdAt ? new Date(user.createdAt).toLocaleDateString("id-ID") : ""}</small>
      </div>
    `).join("")
    : "Belum ada pengguna.";
}

$("refreshUsers").addEventListener("click", () => {
  loadUsers().catch(error => {
    $("usersList").textContent = error.message;
  });
});

// RESTORE SESSION
(async () => {
  try {
    await loadMe();
  } catch (error) {
    console.error("Session:", error);
  }
})();
