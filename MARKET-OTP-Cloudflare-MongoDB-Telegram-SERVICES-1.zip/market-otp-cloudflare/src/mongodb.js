import { DurableObject } from "cloudflare:workers";
import { MongoClient } from "mongodb";

export class MongoDBConnection extends DurableObject {
client;
database;
connected = false;

constructor(ctx, env) {
super(ctx, env);
this.env = env;

this.client = new MongoClient(env.MONGODB_URI, {
  maxPoolSize: 1,
  minPoolSize: 0,
  serverSelectionTimeoutMS: 8000,
  maxIdleTimeMS: 20000
});

this.database = this.client.db(
  env.MONGODB_DB_NAME || "anakjbstore54_db_user"
);

}

async ready() {
if (!this.connected) {
await this.client.connect();
this.connected = true;
}
}

collection(name) {
const allowed = [
"users",
"sessions",
"settings",
"audit_logs",
"transactions",
"orders",
"donations"
];

if (!allowed.includes(name)) {
  throw new Error("Collection tidak diizinkan");
}

return this.database.collection(name);

}

async findOne(name, filter, options = {}) {
await this.ready();
return this.collection(name).findOne(filter, options);
}

async insertOne(name, doc) {
await this.ready();
return this.collection(name).insertOne(doc);
}

async updateOne(name, filter, update, options = {}) {
await this.ready();
return this.collection(name).updateOne(
filter,
update,
options
);
}

async findOneAndUpdate(name, filter, update, options = {}) {
await this.ready();

return this.collection(name).findOneAndUpdate(
  filter,
  update,
  {
    returnDocument: "after",
    includeResultMetadata: false,
    ...options
  }
);

}

async countDocuments(name, filter = {}) {
await this.ready();
return this.collection(name).countDocuments(filter);
}

async findMany(name, filter = {}, limit = 50) {
await this.ready();

return this.collection(name)
  .find(filter)
  .sort({ createdAt: -1 })
  .limit(Math.min(limit, 100))
  .toArray();

}
}