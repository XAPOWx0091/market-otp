
export async function sendTelegram(env, message, websiteUrl) {
  const token = env.TELEGRAM_BOT_TOKEN;
  const chatId = env.TELEGRAM_CHANNEL_ID;

  if (!token || !chatId) {
    throw new Error("Konfigurasi Telegram belum lengkap");
  }

  const url = `https://api.telegram.org/bot${token}/sendMessage`;

  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      chat_id: chatId,
      text: message,
      reply_markup: {
        inline_keyboard: [[
          {
            text: "🌐 Buka MARKET-OTP",
            url: websiteUrl || env.APP_URL
          }
        ]]
      }
    })
  });

  const data = await response.json();

  if (!response.ok || !data.ok) {
    throw new Error("Gagal mengirim notifikasi Telegram");
  }

  return data;
}
