
const DEFAULT_BASE_URL = "https://swiftotp.my.id/api";

export function createSwiftOtpService(env) {
  const baseUrl = (
    env.SWIFTOTP_BASE_URL || DEFAULT_BASE_URL
  ).replace(/\/+$/, "");

  const apiKey = env.SWIFTOTP_API_KEY;

  async function request(path, options = {}) {
    if (!apiKey) {
      throw new Error("SWIFTOTP_API_KEY belum dikonfigurasi");
    }

    const url = new URL(baseUrl + path);

    const headers = {
      Accept: "application/json",
      "Content-Type": "application/json",
      ...(options.headers || {})
    };

    // Format autentikasi harus dicocokkan dengan dokumentasi SwiftOTP.
    // Jangan mengasumsikan nama header API key sebelum diverifikasi.

    const response = await fetch(url, {
      method: options.method || "GET",
      headers,
      body: options.body !== undefined
        ? JSON.stringify(options.body)
        : undefined
    });

    const data = await response.json().catch(() => null);

    if (!response.ok) {
      throw new Error(
        `SwiftOTP request gagal: HTTP ${response.status}`
      );
    }

    return data;
  }

  return {
    // OTP SERVICES
    listServices() {
      return request("/otp/services");
    },

    // OTP COUNTRIES
    listCountries(serviceId) {
      return request(
        "/otp/countries?serviceId=" +
        encodeURIComponent(serviceId)
      );
    },

    // CREATE OTP ORDER
    createOrder(payload) {
      return request("/otp/order", {
        method: "POST",
        body: payload
      });
    },

    // CHECK OTP STATUS
    getOrderStatus(orderId) {
      return request(
        "/otp/status/" + encodeURIComponent(orderId)
      );
    },

    // CANCEL OTP ORDER
    cancelOrder(orderId) {
      return request(
        "/otp/cancel/" + encodeURIComponent(orderId),
        { method: "POST" }
      );
    },

    // CREATE QRIS DEPOSIT
    createDeposit(payload) {
      return request("/deposit/create", {
        method: "POST",
        body: payload
      });
    },

    // CHECK DEPOSIT STATUS
    checkDeposit(depositId) {
      return request(
        "/deposit/check/" + encodeURIComponent(depositId)
      );
    },

    // CANCEL DEPOSIT
    cancelDeposit(depositId) {
      return request(
        "/deposit/cancel/" + encodeURIComponent(depositId),
        { method: "POST" }
      );
    }
  };
}
