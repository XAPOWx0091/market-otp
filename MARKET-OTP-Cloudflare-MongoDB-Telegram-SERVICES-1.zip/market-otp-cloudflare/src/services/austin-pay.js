
const DEFAULT_BASE_URL = "https://austinstore.cc.cd/api";

export function createAustinService(env) {
  const baseUrl = (
    env.AUSTIN_BASE_URL || DEFAULT_BASE_URL
  ).replace(/\/+$/, "");

  const apiKey = env.AUSTIN_API_KEY;

  async function request(path, options = {}) {
    if (!apiKey) {
      throw new Error("AUSTIN_API_KEY belum dikonfigurasi");
    }

    const url = new URL(baseUrl + path);
    url.searchParams.set("apikey", apiKey);

    const response = await fetch(url, {
      method: options.method || "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: options.body !== undefined
        ? JSON.stringify(options.body)
        : undefined
    });

    const data = await response.json().catch(() => null);

    if (!response.ok) {
      throw new Error(`AustinStore HTTP ${response.status}`);
    }

    return data;
  }

  return {
    account: () => request("/account"),

    createDeposit: (amount) =>
      request("/deposit/create", {
        method: "POST",
        body: { amount }
      }),

    checkDeposit: (id) =>
      request(`/deposit/check/${encodeURIComponent(id)}`),

    cancelDeposit: (id) =>
      request(`/deposit/cancel/${encodeURIComponent(id)}`, {
        method: "POST"
      }),

    history: (page = 1) =>
      request(`/deposit/history?page=${page}`)
  };
}
